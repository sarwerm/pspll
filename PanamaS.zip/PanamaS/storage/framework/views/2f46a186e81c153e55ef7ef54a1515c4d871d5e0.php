<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Constra - Construction Html5 Template</title>

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/colorbox.css">

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

	<div class="body-inner">

		<?php echo $__env->make('constraView.inc.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--/ Topbar end -->

		<!-- Header start -->
		<?php echo $__env->make('constraView.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--/ Header end -->

   <div id="banner-area" class="banner-area" style="background-image:url(/constra/images/banner/banner3.jpg)">
      <div class="banner-text">
         <div class="container">
            <div class="row">
               <div class="col-xs-12">
                  <div class="banner-heading">
                     <h1 class="banner-title">Contact</h1>
                     <ol class="breadcrumb">
                        <li>Home</li>
                        <li><a href="#">Contact</a></li>
                     </ol>
                  </div>
               </div><!-- Col end -->
            </div><!-- Row end -->
         </div><!-- Container end -->
      </div><!-- Banner text end -->
   </div><!-- Banner area end --> 


  <section id="main-container" class="main-container">
      <div class="container">

         <div class="row text-center">
            <h2 class="section-title">Reaching our Office</h2>
            <h3 class="section-sub-title">Find Our Location</h3>
         </div><!--/ Title row end -->

         <div class="row">
            <div class="col-md-4">
               <div class="ts-service-box-bg text-center">
                  <span class="ts-service-icon icon-round">
                     <i class="fa fa-map-marker"></i>
                  </span>
                  <div class="ts-service-box-content">
                     <h4>Visit Our Office</h4>
                     <p>Panama SonaMasjid Port Link Ltd.</p>
                 </div>
               </div>
            </div><!-- Col 1 end -->

            <div class="col-md-4">
               <div class="ts-service-box-bg text-center">
                  <span class="ts-service-icon icon-round">
                     <i class="fa fa-envelope"></i>
                  </span>
                  <div class="ts-service-box-content">
                     <h4>Email Us</h4>
                     <p>pspll@pspll.com</p>
                 </div>
               </div>
            </div><!-- Col 2 end -->

            <div class="col-md-4">
               <div class="ts-service-box-bg text-center">
                  <span class="ts-service-icon icon-round">
                     <i class="fa fa-phone-square"></i>
                  </span>
                  <div class="ts-service-box-content">
                     <h4>Call Us</h4>
                     <p>88029999999</p>
                 </div>
               </div>
            </div><!-- Col 3 end -->

         </div><!-- 1st row end -->

         <div class="gap-60"></div>

         <div id="map" class="map"></div>

         <div class="gap-40"></div>

         <div class="row">

            <div class="col-md-12">
               
               <h3 class="column-title">We love to hear</h3>

               <form id="contact-form" action="contact-form.php" method="post" role="form">
                  <div class="error-container"></div>
                  <div class="row">
                     <div class="col-md-4">
                        <div class="form-group">
                           <label>Name</label>
                        <input class="form-control form-control-name" name="name" id="name" placeholder="" type="text" required>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label>Email</label>
                           <input class="form-control form-control-email" name="email" id="email" 
                           placeholder="" type="email" required>
                        </div>
                     </div>
                     <div class="col-md-4">
                        <div class="form-group">
                           <label>Subject</label>
                           <input class="form-control form-control-subject" name="subject" id="subject" 
                           placeholder="" required>
                        </div>
                     </div>
                  </div>
                  <div class="form-group">
                     <label>Message</label>
                     <textarea class="form-control form-control-message" name="message" id="message" placeholder="" rows="10" required></textarea>
                  </div>
                  <div class="text-right"><br>
                     <button class="btn btn-primary solid blank" type="submit">Send Message</button> 
                  </div>
               </form>
            </div>
         
         </div><!-- Content row -->
      </div><!-- Conatiner end -->
   </section><!-- Main container end -->
	

   <?php echo $__env->make('constraView.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Footer end -->


  <!-- Javascript Files
================================================== -->

  <!-- initialize jQuery Library -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.js"></script>
  <!-- Bootstrap jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/bootstrap.min.js"></script>
  <!-- Owl Carousel -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/owl.carousel.min.js"></script>
  <!-- Color box -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.colorbox.js"></script>
  <!-- Isotope -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/isotope.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/ini.isotope.js"></script>


  <!-- Google Map API Key-->
  <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
  <!-- Google Map Plugin-->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/gmap3.js"></script>

 <!-- Template custom -->
 <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/custom.js"></script>

</div><!-- Body inner end -->
</body>

</html><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/pages/contactus.blade.php ENDPATH**/ ?>