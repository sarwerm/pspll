

<?php $__env->startSection('CSS_A'); ?>
	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/colorbox.css">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('constraView.cmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/Home/constracontent.blade.php ENDPATH**/ ?>