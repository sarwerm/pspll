<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Panama Sonamasjid Port Link Ltd.</title>

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/colorbox.css">

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

	<div class="body-inner">

		<?php echo $__env->make('constraView.inc.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--/ Topbar end -->

		<!-- Header start -->
		<?php echo $__env->make('constraView.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <div id="banner-area" class="banner-area" style="background-image:url(/constra/images/Sona_Mosque.jpg)">
      <div class="banner-text">
         <div class="container">
            <div class="row">
               <div class="col-xs-12">
                  <div class="banner-heading">
                     <h1 class="banner-title">News</h1>
                     <ol class="breadcrumb">
                        <li>Home</li>
                        <li>News</li>
                        <li><a href="#">Current News</a></li>
                     </ol>
                  </div>
               </div><!-- Col end -->
            </div><!-- Row end -->
         </div><!-- Container end -->
      </div><!-- Banner text end -->
   </div><!-- Banner area end --> 


   <section id="main-container" class="main-container">
		<div class="container">
			<div class="row">

				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

					<div class="sidebar sidebar-left">


						<div class="widget recent-posts">
							<h3 class="widget-title">Recent Posts</h3>
							<ul class="unstyled clearfix">
		               	<li>
		                    <div class="posts-thumb pull-left"> 
		                    		<a href="news-single.html"><img alt="img" src="/constra/images/security/Entrance_seurity.jpg"></a>
		                    </div>
		                    <div class="post-info">
		                        <h4 class="entry-title">
		                        	<a href="news-single.html">Trade thru land ports comes to a halt</a>
		                        </h4>
		                    </div>
		                    <div class="clearfix"></div>
		                  </li><!-- 1st post end-->

		                  <li>
		                    <div class="posts-thumb pull-left"> 
		                    		<a href="news-single.html"><img alt="img" src="/constra/images/building/Construction_view.jpg"></a>
		                    </div>
		                    <div class="post-info">
		                        <h4 class="entry-title">
		                        	<a href="news-single.html">Sonamasjid Land Port to be int’l standard: Shahriar</a>
		                        </h4>
		                    </div>
		                    <div class="clearfix"></div>
		                  </li><!-- 2nd post end-->

		                  <li>
		                    <div class="posts-thumb pull-left"> 
		                    		<a href="news-single.html"><img alt="img" src="/constra/images/smasjid4.jpg"></a>
		                    </div>
		                    <div class="post-info">
		                        <h4 class="entry-title">
		                        	<a href="news-single.html">Revenue earnings of Sonamasjid land port exceeds target</a>
		                        </h4>
		                    </div>
		                    <div class="clearfix"></div>
		                  </li><!-- 3rd post end-->

		               </ul>
							
						</div><!-- Recent post end -->

						<div class="widget">
							<h3 class="widget-title">Categories</h3>
							<ul class="arrow nav nav-tabs nav-stacked">
		                  <li><a href="#">Construction</a></li>
		                  <li><a href="#">Commercial</a></li>
		                  <li><a href="#">Building</a></li>
		                  <li><a href="#">Safety</a></li>
		                  <li><a href="#">Structure</a></li>
		              	</ul>
						</div><!-- Categories end -->

						<div class="widget">
							<h3 class="widget-title">Archives </h3>
							<ul class="arrow nav nav-tabs nav-stacked">
			              	<li><a href="#">Feburay 2016</a></li>
		                  <li><a href="#">January 2016</a></li>
		                  <li><a href="#">December 2015</a></li>
		                  <li><a href="#">November 2015</a></li>
		                  <li><a href="#">October 2015</a></li>
			            </ul>
						</div><!-- Archives end -->

						<div class="widget widget-tags">
							<h3 class="widget-title">Tags </h3>

							<ul class="unstyled clearfix">
			              	<li><a href="#">Construction</a></li>
		                  <li><a href="#">Design</a></li>
		                  <li><a href="#">Project</a></li>
		                  <li><a href="#">Building</a></li>
		                  <li><a href="#">Finance</a></li>
		                  <li><a href="#">Safety</a></li>
		                  <li><a href="#">Contracting</a></li>
		                  <li><a href="#">Planning</a></li>
			            </ul>
						</div><!-- Tags end -->


					</div><!-- Sidebar end -->
				</div><!-- Sidebar Col end -->

				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
					<div class="post">
						<div class="post-media post-image">
							<img src="/constra/images/security/security_03.jpg" class="img-responsive" alt="">
						</div>

						<div class="post-body">
							<div class="entry-header">
					 			<div class="post-meta">
									<span class="post-author">
										<i class="fa fa-user"></i><a href="#"> Admin</a>
   								</span>
									<span class="post-cat">
										<i class="fa fa-folder-open"></i><a href="#"> News</a>
   								</span>
   								<span class="post-meta-date"><i class="fa fa-calendar"></i> March 25, 2020</span>
									<span class="post-comment"><i class="fa fa-comment-o"></i> 03<a href="#" class="comments-link">Comments</a></span>
								</div>
								<h2 class="entry-title">
					 				<a href="news-single.html">Trade thru land ports comes to a halt</a>
					 			</h2>
							</div><!-- header end -->

							<div class="entry-content">
								<p>Bangladesh's trade with India through most of the land ports has come to a halt since Monday as the neighbour went into a lockdown the previous day in an effort to contain the spread of deadly coronavirus.</p>

<p>Twelve land ports under Bangladesh Land Port Authority wore a deserted look yesterday, as the Indian shutdown came at a time when the Bangladesh government announced a 10-day general holiday from March 26 for the same purpose.

Bangladesh earned Tk 195.44 crore in revenue in fiscal 2018-19 by exporting 1,335,930 tonnes of goods and importing 20,321,077 tonnes through the land ports, according to the port authority.  ...</p>
							</div>

							<div class="post-footer">
								<a href="news-single.html" class="btn btn-primary">Continue Reading</a>
							</div>

						</div><!-- post-body end -->
					</div><!-- 1st post end -->

					
					<div class="post">
						<!--<div class="post-media post-video">
							<div class="embed-responsive"> -->
								<!-- Change the url -->
								<!--
								<iframe src="//player.vimeo.com/video/153089270?title=0&amp;byline=0&amp;portrait=0&amp;color=8aba56" width="500" height="281" allowfullscreen></iframe> -->
					<!--		</div> -->
					<!--	</div> -->

						<div class="post-body">
							<div class="entry-header">
					 			<div class="post-meta">
									<span class="post-author">
										<i class="fa fa-user"></i><a href="#"> Admin</a>
   								</span>
									<span class="post-cat">
										<i class="fa fa-folder-open"></i><a href="#"> News</a>
   								</span>
   								<span class="post-meta-date"><i class="fa fa-calendar"></i> August 18, 2019</span>
									<span class="post-comment"><i class="fa fa-comment-o"></i> 03<a href="#" class="comments-link">Comments</a></span>
								</div>
								<h2 class="entry-title">
					 				<a href="news-single.html">Sonamasjid Land Port to be int’l standard: Shahriar</a>
					 			</h2>
							</div><!-- header end -->

							<div class="entry-content">
								<p>State Minister for Foreign Affairs Shahriar
Alam has said the Sonamasjid Land Port in Chapainawabganj will be transformed
into a model one through upgrading it to international standard.</p>
<p>
“Necessary works for transforming some of the country’s land ports into
model ones are progressing fast in the first phase,” he said while addressing
a view-sharing meeting with all stakeholders of the port as the chief guest
with Deputy Commissioner AZM Nurul Haque in the chair.</p>

<p>In line with the development spree, the Sonamasjid Land Port, second
largest land port of the country, will be elevated to an international
standard in phases, the state minister said.
 ...</p>
							</div>

							<div class="post-footer">
								<a href="news-single.html" class="btn btn-primary">Continue Reading</a>
							</div>

						</div><!-- post-body end -->
					</div><!-- 2nd post end -->

					<div class="post">
						<div class="post-media post-image">
							<img src="/constra/images/smasjid1.jpg" class="img-responsive" alt="">
						</div>

						<div class="post-body">
							<div class="entry-header">
					 			<div class="post-meta">
									<span class="post-author">
										<i class="fa fa-user"></i><a href="#"> Admin</a>
   								</span>
									<span class="post-cat">
										<i class="fa fa-folder-open"></i><a href="#"> News</a>
   								</span>
   								<span class="post-meta-date"><i class="fa fa-calendar"></i> Sept 23, 2019</span>
									<span class="post-comment"><i class="fa fa-comment-o"></i> 03<a href="#" class="comments-link">Comments</a></span>
								</div>
								<h2 class="entry-title">
					 				<a href="news-single.html">Revenue earnings of Sonamasjid land port exceeds target</a>
					 			</h2>
							</div><!-- header end -->

							<div class="entry-content">
								<p>Revenue earnings of Sona Masjid land port has surpassed the target during the period from February to June 2019, informed Dr Shamil Uddin Ahmed Shimul, MP, Shibganj constituency, at a press conference in Chapainawabganj recently. </p>
								<p>
Dr. Shamil Uddin Ahmed said the target of revenue earning from February to June-2019 was fixed at Tk 1.36 billion but due to cooperation from all concerned, the revenue earning surpassed the target to Tk 1.87 billion.
  ...</p>
							</div>

							<div class="post-footer">
								<a href="news-single.html" class="btn btn-primary">Continue Reading</a>
							</div>

						</div><!-- post-body end -->
					</div><!-- 3rd post end -->

					<div class="paging">
		            <ul class="pagination">
		              <li><a href="#"><i class="fa fa-angle-double-left"></i></a></li>
		              <li class="active"><a href="#">1</a></li>
		              <li><a href="#">2</a></li>
		              <li><a href="#">3</a></li>
		              <li><a href="#">4</a></li>
		              <li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
		            </ul>
	          	</div>

				</div><!-- Content Col end -->

			</div><!-- Main row end -->

		</div><!-- Container end -->
	</section><!-- Main container end -->
	


<?php echo $__env->make('constraView.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<!-- Javascript Files
================================================== -->

	<!-- initialize jQuery Library -->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.js"></script>
	<!-- Bootstrap jQuery -->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/bootstrap.min.js"></script>
	<!-- Owl Carousel -->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/owl.carousel.min.js"></script>
	<!-- Color box -->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.colorbox.js"></script>
	<!-- Isotope -->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/isotope.js"></script>
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/ini.isotope.js"></script>


	<!-- Google Map API Key-->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
	<!-- Google Map Plugin-->
	<script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/gmap3.js"></script>

 <!-- Template custom -->
 <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/custom.js"></script>

</div><!-- Body inner end -->
</body>

</html><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/pages/news.blade.php ENDPATH**/ ?>