

<?php echo $__env->make('FrontView.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Ampps\www\PanamaS\resources\views/FrontView/Home/homecontent.blade.php ENDPATH**/ ?>