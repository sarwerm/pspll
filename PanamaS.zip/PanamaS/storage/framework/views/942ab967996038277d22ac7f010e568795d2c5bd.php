<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Panama Sonamasjid Port Link Ltd.</title>

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/colorbox.css">

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

	<div class="body-inner">

		<?php echo $__env->make('constraView.inc.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--/ Topbar end -->

		<!-- Header start -->
		<?php echo $__env->make('constraView.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		
		<!--/ Header end --> 

 

   <div id="banner-area" class="banner-area" style="background-image:url(/constra/images/Sona_Mosque.jpg)">  
      <div class="banner-text">
         <div class="container">
            <div class="row">
               <div class="col-xs-12">
                  <div class="banner-heading">
                     <h1 class="banner-title">About Us</h1>
                     <ol class="breadcrumb">
                        <li>Home</li>
                        <li>Company</li>
                        <li><a href="#">About Us</a></li>
                     </ol>
                  </div>
               </div><!-- Col end -->
            </div><!-- Row end -->
         </div><!-- Container end -->
      </div><!-- Banner text end -->
   </div><!-- Banner area end --> 



   <section id="main-container" class="main-container">
      <div class="container">
         <div class="row">
            <div class="col-md-6">
               <h3 class="column-title">Who We Are </h3>

               <p>Land Ports also called border stations for import and export. A land port houses the customs and border protection, and other inspection agencies responsible for the enforcement of country’s laws pertaining to such activities. The land port of entry consists of the land, the buildings, and the on-site roadways and parking lots that the port of entry occupies. The facility serves as a point of contact for travelers entering or leaving the country for the purposes of enforcement; Prevention of illegal aliens from entering the country; Collection of revenues; Prevention of injurious plants, animal pests, human and animal diseases from entering the country; Examination of export and import documents; Registration of valuable articles being temporarily taken out of the country; and Commercial transactions. </p>


				<p>Bangladesh side: Shibganj, Chapai Nawabganj </p>
<p>Indian side: Mahadipur, Maldah, West Bengal, India</p>
<p>Operator (on BOT basis): Panama Sonamosjid Port Link Ltd. </p>
<p>Date of declaration: 12/01/2002</p>
<p>Date of operation: December 27, 2006</p>
<p>Date of signing of Concession Agreement
with the Operator: October 09, 2005 </p>
<p>Commercial Operation Date (COD): May 20, 2010 </p>
<p>Royalty from operator: Fixed: Tk. 30,00 lakh</p>
<p>Variable: 49% of gross revenue income </p>
<p>Storage capacity: 1,000 MT</p>
<p>Land area: 19.13 Acre</p>
<p>Infrastructure: Warehouse-5, Transhipment Shed-1, Warehouse-2, RCC Road & Barack Building-1 are
under constraction Open stack yard-2, Transshipment yard-2, Weigh bridge-3 (100 (MT),
Standby power generator, Administrative building, dormitory, Standby power generator,
Lighting, Security posts, Observation tower, Boundary wall etc.</p>
<p>Handling capacity: 2.0 mln MT (manual-yearly)</p>
<p>Principal imports: Rice, Wheat, Onion, Fruits, Fly ash etc.</p>
<p>Principal exports: Jute & Jute goods, Cement, Battery, etc.</p>

               

            </div><!-- Col end -->

            <div class="col-md-6">
               
               <div id="page-slider" class="owl-carousel owl-theme page-slider small-bg">

                  <div class="item" style="background-image:url(constra/images/mask_dist/Mask_distribution05.jpg)">
                     <div class="container">
                        <div class="box-slider-content">
                           <div class="box-slider-text">
                              <h2 class="box-slide-title">Leadership</h2>
                           </div>    
                        </div>
                     </div>
                  </div><!-- Item 1 end -->

                  <div class="item" style="background-image:url(constra/images/smasjid1.jpg)">
                     <div class="container">
                        <div class="box-slider-content">
                           <div class="box-slider-text">
                              <h2 class="box-slide-title">Relationships</h2>
                           </div>    
                        </div>
                     </div>
                  </div><!-- Item 1 end -->

                  <div class="item" style="background-image:url(constra/images/slider-pages/slide-page3.jpg)">
                     <div class="container">
                        <div class="box-slider-content">
                           <div class="box-slider-text">
                              <h2 class="box-slide-title">Performance</h2>
                           </div>    
                        </div>
                     </div>
                  </div><!-- Item 1 end -->
               </div><!-- Page slider end-->          
            

            </div><!-- Col end -->
         </div><!-- Content row end -->

      </div><!-- Container end -->
   </section><!-- Main container end -->

   <section id="facts" class="facts-area dark-bg">
      <div class="container">
         <div class="row">
            <div class="facts-wrapper">
               <div class="col-sm-3 ts-facts">
                  <div class="ts-facts-img">
                     <img src="images/icon-image/fact1.png" alt="" />
                  </div>
                  <div class="ts-facts-content">
                     <h2 class="ts-facts-num"><span class="counterUp">1789</span></h2>
                     <h3 class="ts-facts-title">Total Projects</h3>
                  </div>
               </div><!-- Col end -->

               <div class="col-sm-3 ts-facts">
                  <div class="ts-facts-img">
                     <img src="images/icon-image/fact2.png" alt="" />
                  </div>
                  <div class="ts-facts-content">
                     <h2 class="ts-facts-num"><span class="counterUp">647</span></h2>
                     <h3 class="ts-facts-title">Staff Members</h3>
                  </div>
               </div><!-- Col end -->

               <div class="col-sm-3 ts-facts">
                  <div class="ts-facts-img">
                     <img src="images/icon-image/fact3.png" alt="" />
                  </div>
                  <div class="ts-facts-content">
                     <h2 class="ts-facts-num"><span class="counterUp">4000</span></h2>
                     <h3 class="ts-facts-title">Hours of Work</h3>
                  </div>
               </div><!-- Col end -->

               <div class="col-sm-3 ts-facts">
                  <div class="ts-facts-img">
                     <img src="images/icon-image/fact4.png" alt="" />
                  </div>
                  <div class="ts-facts-content">
                     <h2 class="ts-facts-num"><span class="counterUp">44</span></h2>
                     <h3 class="ts-facts-title">Countries Experience</h3>
                  </div>
               </div><!-- Col end -->

            </div> <!-- Facts end -->
         </div><!--/ Content row end -->
      </div><!--/ Container end -->
   </section><!-- Facts end -->

   <section id="ts-team" class="ts-team">
      <div class="container">
         <div class="row text-center">
            <h2 class="section-title">Quality Service</h2>
            <h3 class="section-sub-title">Professional Team</h3>
         </div><!--/ Title row end -->

         <div class="row">

            <div id="team-slide" class="owl-carousel owl-theme team-slide">
               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team1.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Nats Stenman</h3>
                        <p class="ts-designation">Chief Operating Officer</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 1 end -->

               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team2.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Angela Lyouer</h3>
                        <p class="ts-designation">Innovation Officer</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 2 end -->

               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team3.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Mark Conter</h3>
                        <p class="ts-designation">Safety Officer</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 3 end -->

               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team4.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Ayesha Stewart</h3>
                        <p class="ts-designation">Finance Officer</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 4 end -->

               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team5.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Dave Clarkte</h3>
                        <p class="ts-designation">Civil Engineer</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 5 end -->

               <div class="item">
                  <div class="ts-team-wrapper">
                     <div class="team-img-wrapper">
                        <img alt="" src="images/team/team6.jpg" class="img-responsive">
                     </div>
                     <div class="ts-team-content">
                        <h3 class="ts-name">Elton Joe</h3>
                        <p class="ts-designation">Site Supervisor</p>
                        <p class="ts-description">Nats Stenman began his career in construction with boots on the ground</p>
                        <div class="team-social-icons">
                           <a target="_blank" href="#"><i class="fa fa-facebook"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-twitter"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-google-plus"></i></a>
                           <a target="_blank" href="#"><i class="fa fa-linkedin"></i></a>
                        </div><!--/ social-icons-->
                     </div>
                  </div><!--/ Team wrapper end -->
               </div><!-- Team 6 end -->

            </div><!-- Team slide end -->

         </div><!--/ Content row end -->
      </div><!--/ Container end -->
   </section><!--/ Team end -->
	
   <?php echo $__env->make('constraView.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <!-- Footer end -->


  <!-- Javascript Files
================================================== -->

  <!-- initialize jQuery Library -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.js"></script>
  <!-- Bootstrap jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/bootstrap.min.js"></script>
  <!-- Owl Carousel -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/owl.carousel.min.js"></script>
  <!-- Color box -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.colorbox.js"></script>
  <!-- Isotope -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/isotope.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/ini.isotope.js"></script>


  <!-- Google Map API Key-->
  <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
  <!-- Google Map Plugin-->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/gmap3.js"></script>

 <!-- Template custom -->
 <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/custom.js"></script>

</div><!-- Body inner end -->
</body>

</html><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/pages/about.blade.php ENDPATH**/ ?>