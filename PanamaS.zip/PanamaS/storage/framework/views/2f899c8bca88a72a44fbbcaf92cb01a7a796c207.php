<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Constra - Construction Html5 Template</title>

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="<?php echo e(asset('constra')); ?>/css/colorbox.css">

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

	<div class="body-inner">

		<?php echo $__env->make('constraView.inc.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->make('constraView.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		

   <div id="banner-area" class="banner-area" style="background-image:url(/constra/images/banner/banner2.jpg)">
      <div class="banner-text">
         <div class="container">
            <div class="row">
               <div class="col-xs-12">
                  <div class="banner-heading">
                     <h1 class="banner-title">Projects</h1>
                     <ol class="breadcrumb">
                        <li>Home</li>
                        <li>Projects</li>
                        <li><a href="#">Projects All</a></li>
                     </ol>
                  </div>
               </div><!-- Col end -->
            </div><!-- Row end -->
         </div><!-- Container end -->
      </div><!-- Banner text end -->
   </div><!-- Banner area end --> 


   <section id="project-area" class="project-area solid-bg">
			<div class="container">
				<div class="row text-center">
					<h2 class="section-title">Work of Excellence</h2>
					<h3 class="section-sub-title">Recent Projects</h3>
				</div>
				<!--/ Title row end -->

				<div class="row">
					<div class="isotope-nav" data-isotope-nav="isotope">
						<ul>
							<li><a href="#" class="active" data-filter="*">Show All</a></li>
							<li><a href="#" data-filter=".commercial">Warehouse Construction</a></li>
							<li><a href="#" data-filter=".education">Mask Distribution </a></li>
							<li><a href="#" data-filter=".government">Relief Distribution</a></li>
							<li><a href="#" data-filter=".infrastructure">Security</a></li>
							<li><a href="#" data-filter=".residential">Road Construction</a></li>
							<li><a href="#" data-filter=".healthcare">Disinfecting</a></li>
						</ul>
					</div><!-- Isotope filter end -->


					<div id="isotope" class="isotope">
						<div class="col-md-4 col-sm-6 col-xs-12 commercial isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/building/Building_constr.jpg">
									<img class="img-responsive" src="/constra/images/building/Building_constr.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Capital Teltway Building</a>
										</h3>
										<p class="project-cat">Commercial, Interiors</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 1 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 healthcare isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/disinfect/Disinfecting_03.jpg">
									<img class="img-responsive" src="/constra/images/disinfect/Disinfecting_03.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Ghum Touch Hospital</a>
										</h3>
										<p class="project-cat">Healthcare</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 2 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 government isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/relief/Releif_distr_prog.jpg">
									<img class="img-responsive" src="/constra/images/relief/Relief_distr_prog.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">TNT East Facility</a>
										</h3>
										<p class="project-cat">Government</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 3 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 education isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/mask_dist/Mask_Distribution.jpg">
									<img class="img-responsive" src="/constra/images/mask_dist/Mask_Distribution.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Narriot Headquarters</a>
										</h3>
										<p class="project-cat">Infrastructure</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 4 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 infrastructure isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/security/Fingerprint_security02.jpg">
									<img class="img-responsive" src="/constra/images/security/Fingerprint_security02.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Kalas Metrorail</a>
										</h3>
										<p class="project-cat">Infrastructure</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 5 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 residential isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/building/Building_constru_02.jpg">
									<img class="img-responsive" src="/constra/images/building/Building_constru_02.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Ancraft Avenue House</a>
										</h3>
										<p class="project-cat">Residential</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 6 end -->
					</div><!-- Isotop end -->

					<div class="general-btn text-center">
						<a class="btn btn-primary" href="projects.html">View All Projects</a>
					</div>

				</div><!-- Content row end -->
			</div>
			<!--/ Container end -->
		</section><!-- Project area end -->

	

   <?php echo $__env->make('constraView.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <!-- Javascript Files
================================================== -->

  <!-- initialize jQuery Library -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.js"></script>
  <!-- Bootstrap jQuery -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/bootstrap.min.js"></script>
  <!-- Owl Carousel -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/owl.carousel.min.js"></script>
  <!-- Color box -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/jquery.colorbox.js"></script>
  <!-- Isotope -->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/isotope.js"></script>
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/ini.isotope.js"></script>


  <!-- Google Map API Key-->
  <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
  <!-- Google Map Plugin-->
  <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/gmap3.js"></script>

 <!-- Template custom -->
 <script type="text/javascript" src="<?php echo e(asset('constra')); ?>/js/custom.js"></script>

</div><!-- Body inner end -->
</body>

</html><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/pages/projects.blade.php ENDPATH**/ ?>