<header id="header" class="header-one">
			<div class="container">
				<div class="row">
					<div class="logo-area clearfix">
						<div class="logo col-xs-12 col-md-3">
							<a href="/">
								<img class="mx-auto rounded-circle" src="<?php echo e(asset ('constra')); ?>/images/pspll_logo.jpg" alt= BGPic Width= "70" height="70" >
								<span> <b>PSPLL </b></span>
							</a>

						</div><!-- logo end -->

						<div class="col-xs-12 col-md-9 header-right">
							<ul class="top-info-box">
								<li>
									<div class="info-box">
										<div class="info-box-content">
											<p class="info-box-title">Call Us</p>
											<p class="info-box-subtitle">88029999999</p>
										</div>
									</div>
								</li>
								<li>
									<div class="info-box">
										<div class="info-box-content">
											<p class="info-box-title">Email Us</p>
											<p class="info-box-subtitle">pspll@pspll.com</p>
										</div>
									</div>
								</li>
								<li class="last">
									<div class="info-box last">
										<div class="info-box-content">
											<p class="info-box-title">Bangladesh Land Port Authority</p>
											<a href = "http://bsbk.portal.gov.bd/ ">
											<p class="info-box-subtitle">  bsbk.portal.gov.bd </a></p>
										</div>
									</div>
								</li>
								<li class="header-get-a-quote">
									<a class="btn btn-primary" href="/contactus">Contact Us</a>
								</li>
							</ul><!-- Ul end -->
						</div><!-- header right end -->
					</div><!-- logo area end -->

				</div><!-- Row end -->
			</div><!-- Container end -->
			<?php echo $__env->make('constraView.inc.cnavigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			</header>
		<!--/ Header end --><?php /**PATH C:\Ampps\www\PanamaS\resources\views/constraView/inc/header.blade.php ENDPATH**/ ?>