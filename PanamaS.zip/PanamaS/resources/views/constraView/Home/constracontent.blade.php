@extends ('constraView.cmaster')

@section ('CSS_A')
	<!-- CSS
	================================================== -->

	<!-- Bootstrap -->
	<link rel="stylesheet" href="{{asset('constra')}}/css/bootstrap.min.css">
	<!-- Template styles-->
	<link rel="stylesheet" href="{{asset('constra')}}/css/style.css">
	<!-- Responsive styles-->
	<link rel="stylesheet" href="{{asset('constra')}}/css/responsive.css">
	<!-- FontAwesome -->
	<link rel="stylesheet" href="{{asset('constra')}}/css/font-awesome.min.css">
	<!-- Animation -->
	<link rel="stylesheet" href="{{asset('constra')}}/css/animate.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="{{asset('constra')}}/css/owl.carousel.min.css">
	<link rel="stylesheet" href="{{asset('constra')}}/css/owl.theme.default.min.css">
	<!-- Colorbox -->
	<link rel="stylesheet" href="{{asset('constra')}}/css/colorbox.css">

@endsection

