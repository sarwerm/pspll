<!DOCTYPE html>
<html lang="en">

<head>

	<!-- Basic Page Needs
	================================================== -->
	<meta charset="utf-8">
	<title>Panama Sonamasjid Port Link Ltd.</title>

	<!-- Mobile Specific Metas
	================================================== -->

	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">


	@yield ('CSS_A')

	<!-- HTML5 shim, for IE6-8 support of HTML5 elements. All other JS at the end of file. -->
	<!--[if lt IE 9]>
      <script src="js/html5shiv.js"></script>
      <script src="js/respond.min.js"></script>
    <![endif]-->

</head>

<body>

	<div class="body-inner">

		 @include ('constraView.inc.topbar')

		

		 @include ('constraView.inc.header') 

		 		

		<!-- Carousel -->
		<div id="main-slide" class="carousel slide" data-ride="carousel">

			<!-- Indicators -->
			<ol class="carousel-indicators visible-lg visible-md">
				<li data-target="#main-slide" data-slide-to="0" class="active"></li>
				<li data-target="#main-slide" data-slide-to="1"></li>
				<li data-target="#main-slide" data-slide-to="2"></li>
			</ol>
			<!--/ Indicators end-->

			<!-- Carousel inner -->
			<div class="carousel-inner">

				<div class="item active" style="background-image:url(constra/images/Sonamasjid_001.jpg)">
					<div class="slider-content">
						<div class="col-md-100 text-center">
							<h2 class="slide-title animated4">PSPLL</h2>
							<h3 class="slide-sub-title animated5">Panama Port Services</h3>
							<p>
								<a href="services.html" class="slider btn btn-primary">Our Services</a>
								<a href="/contactus" class="slider btn btn-primary border">Contact Now</a>
							</p>
						</div>
					</div>
				</div>
				<!--/ Carousel item 1 end -->

				<div class="item" style="background-image:url(constra/images/smasjid3.jpg)">
					<div class="slider-content text-left">
						<div class="col-md-12">
							<h2 class="slide-title-box animated2">World Class Service</h2>
							<h3 class="slide-title animated3">When Service Matters</h3>
							<h3 class="slide-sub-title animated3">Your Choice is Simple</h3>
							<p class="animated3">
								<a href="services.html" class="slider btn btn-primary border">Our Services</a>
							</p>
						</div>
					</div>
				</div>
				<!--/ Carousel item 2 end -->

				<div class="item" style="background-image:url(constra/images/smasjid4.jpg)">
					<div class="slider-content text-right">
						<div class="col-md-12">
							<h2 class="slide-title animated6">Meet Our Engineers</h2>
							<h3 class="slide-sub-title animated7">We believe sustainability</h3>
							<p class="slider-description lead animated7">We will deal with your failure that determines how you
								achieve success.</p>
							<p>
								<a href="/contactus" class="slider btn btn-primary">Get Free Quote</a>
								<a href="/aboutus" class="slider btn btn-primary border">Learn More</a>
							</p>
						</div>
					</div>
				</div>
				<!--/ Carousel item 3 end -->

			</div><!-- Carousel inner end-->

			<!-- Controllers -->
			<a class="left carousel-control" href="#main-slide" data-slide="prev">
				<span><i class="fa fa-angle-left"></i></span>
			</a>
			<a class="right carousel-control" href="#main-slide" data-slide="next">
				<span><i class="fa fa-angle-right"></i></span>
			</a>
		</div>
		<!--/ Carousel end -->

		<section class="call-to-action-box no-padding">
			<div class="container">
				<div class="action-style-box">
					<div class="row">
						<div class="col-md-10">
							<div class="call-to-action-text">
								<h3 class="action-title">We understand your needs on PSPLL</h3>
							</div>
						</div><!-- Col end -->
						<div class="col-md-2">
							<div class="call-to-action-btn">
								<a class="btn btn-dark" href="#">Request Rate</a>
							</div>
						</div><!-- col end -->
					</div><!-- row end -->
				</div><!-- Action style box -->
			</div><!-- Container end -->
		</section><!-- Action end -->

		<section id="ts-features" class="ts-features">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-xs-12">
						<div class="ts-intro">
							<h2 class="into-title">About Us</h2>
							<h3 class="into-sub-title">Panama Sonamasjid Port Link Ltd.</h3>
							<p>PSPLL houses the customs and border protection, and other inspection agencies responsible for the enforcement of country’s laws pertaining to such activities. The land port of entry consists of the land, the buildings, and the on-site roadways and parking lots that the port of entry occupies..</p>
						</div><!-- Intro box end -->

						<div class="gap-20"></div>

						<div class="row">
							<div class="col-md-6">
								<div class="ts-service-box">
									<span class="ts-service-icon">
										<i class="fa fa-trophy"></i>
									</span>
									<div class="ts-service-box-content">
										<h3 class="service-box-title">We've Repution for Excellence</h3>
									</div>
								</div><!-- Service 1 end -->
							</div><!-- col end -->

							<div class="col-md-6">
								<div class="ts-service-box">
									<span class="ts-service-icon">
										<i class="fa fa-sliders"></i>
									</span>
									<div class="ts-service-box-content">
										<h3 class="service-box-title">We Build Partnerships</h3>
									</div>
								</div><!-- Service 2 end -->
							</div><!-- col end -->
						</div><!-- Content row 1 end -->

						<div class="row">
							<div class="col-md-6">
								<div class="ts-service-box">
									<span class="ts-service-icon">
										<i class="fa fa-thumbs-up"></i>
									</span>
									<div class="ts-service-box-content">
										<h3 class="service-box-title">Guided by Commitment</h3>
									</div>
								</div><!-- Service 1 end -->
							</div><!-- col end -->

							<div class="col-md-6">
								<div class="ts-service-box">
									<span class="ts-service-icon">
										<i class="fa fa-users"></i>
									</span>
									<div class="ts-service-box-content">
										<h3 class="service-box-title">A Team of Professionals</h3>
									</div>
								</div><!-- Service 2 end -->
							</div><!-- col end -->
						</div><!-- Content row 1 end -->
					</div><!-- Col end -->

					<div class="col-md-6 col-xs-12">
						<h3 class="into-sub-title">Our Values</h3>
						<p>Description to be added .</p>
						<div class="panel-group" id="accordion">
							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">Safety</a>
									</h4>
								</div>
								<div id="collapseOne" class="panel-collapse collapse in">
									<div class="panel-body">
										<p>Description to de added if needed</p>
									</div>
								</div>
							</div>
							<!--/ Panel 1 end-->

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseTwo"> Customer
											Service</a>
									</h4>
								</div>
								<div id="collapseTwo" class="panel-collapse collapse">
									<div class="panel-body">
										<p>Description to be added if needed</p>
									</div>
								</div>
							</div>
							<!--/ Panel 2 end-->


							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title">
										<a data-toggle="collapse" class="collapsed" data-parent="#accordion" href="#collapseThree">
											Integrity</a>
									</h4>
								</div>
								<div id="collapseThree" class="panel-collapse collapse">
									<div class="panel-body">
										<p>Description to be added.</p>
									</div>
								</div>
							</div>
							<!--/ Panel 3 end-->

						</div>
						<!--/ Accordion end -->

					</div><!-- Col end -->
				</div><!-- Row end -->
			</div><!-- Container end -->
		</section><!-- Feature are end -->


				<section id="facts" class="facts-area dark-bg">
			<div class="container">
				<div class="row">
					<div class="facts-wrapper">
						<div class="col-sm-3 ts-facts">
						</div>
					</div>
				</div>
			</div>
		</section>


		

		<section id="ts-service-area" class="ts-service-area">
			<div class="container">
				<div class="row text-center">
					<h2 class="section-title">What are the services we provide</h2>
					<h3 class="section-sub-title">What We Do</h3>
				</div>
				<!--/ Title row end -->

				<!--

				<div class="row">
					<div class="col-md-4">
						<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon1.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Home Construction</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div> -->
					<!--	</div> --><!-- Service 1 end -->

					<!--	<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon2.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Building Remodels</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div>
						</div>--><!-- Service 2 end -->

					<!--	<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon3.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Interior Design</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div>
						</div>--><!-- Service 3 end -->

					</div><!-- Col end -->

					<!--<div class="col-md-4 text-center">
						<img class="service-center-img img-responsive" src="images/services/service-center.jpg" alt="" />
					</div>--><!-- Col end -->

					<!--<div class="col-md-4">
						<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon4.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Exterior Design</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div>
						</div>--><!-- Service 4 end -->

						<!--<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon5.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Renovation</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div>
						</div>--><!-- Service 5 end -->

						<!--<div class="ts-service-box">
							<div class="ts-service-box-img pull-left">
								<img src="images/icon-image/service-icon6.png" alt="" />
							</div>
							<div class="ts-service-box-info">
								<h3 class="service-box-title"><a href="#">Safety Management</a></h3>
								<p>Lorem ipsum dolor sit amet consectetur adipiscing elit Integer adipiscing erat</p>
							</div>
						</div>--><!-- Service 6 end -->
					<!--</div>--><!-- Col end -->
				<!--</div> --><!-- Content row end -->

			</div>
			<!--/ Container end -->
		</section><!-- Service end -->

		<section id="project-area" class="project-area solid-bg">
			<div class="container">
				<div class="row text-center">
					<h2 class="section-title">Work of Excellence</h2>
					<h3 class="section-sub-title">Recent Projects</h3>
				</div>
				<!--/ Title row end -->

				<div class="row">
					<div class="isotope-nav" data-isotope-nav="isotope">
						<ul>
							<li><a href="#" class="active" data-filter="*">Show All</a></li>
							<li><a href="#" data-filter=".commercial">Warehouse Construction</a></li>
							<li><a href="#" data-filter=".education">Mask Distribution </a></li>
							<li><a href="#" data-filter=".government">Relief Distribution</a></li>
							<li><a href="#" data-filter=".infrastructure">Security</a></li>
							<li><a href="#" data-filter=".residential">Road Construction</a></li>
							<li><a href="#" data-filter=".healthcare">Disinfecting</a></li>
						</ul>
					</div><!-- Isotope filter end -->


					<div id="isotope" class="isotope">
						<div class="col-md-4 col-sm-6 col-xs-12 commercial isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/building/Building_constr.jpg">
									<img class="img-responsive" src="constra/images/building/Building_constr.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Capital Teltway Building</a>
										</h3>
										<p class="project-cat">Commercial, Interiors</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 1 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 healthcare isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/disinfect/Disinfecting_03.jpg">
									<img class="img-responsive" src="constra/images/disinfect/Disinfecting_03.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Ghum Touch Hospital</a>
										</h3>
										<p class="project-cat">Healthcare</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 2 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 government isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/relief/Releif_distr_prog.jpg">
									<img class="img-responsive" src="constra/images/relief/Relief_distr_prog.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">TNT East Facility</a>
										</h3>
										<p class="project-cat">Government</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 3 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 education isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/mask_dist/Mask_Distribution.jpg">
									<img class="img-responsive" src="constra/images/mask_dist/Mask_Distribution.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Narriot Headquarters</a>
										</h3>
										<p class="project-cat">Infrastructure</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 4 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 infrastructure isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/security/Fingerprint_security02.jpg">
									<img class="img-responsive" src="constra/images/security/Fingerprint_security02.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Kalas Metrorail</a>
										</h3>
										<p class="project-cat">Infrastructure</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 5 end -->

						<div class="col-md-4 col-sm-6 col-xs-12 residential isotope-item">
							<div class="isotope-img-container">
								<a class="gallery-popup" href="constra/images/building/Building_constru_02.jpg">
									<img class="img-responsive" src="constra/images/building/Building_constru_02.jpg" alt="">
									<span class="gallery-icon"><i class="fa fa-plus"></i></span>
								</a>
								<div class="project-item-info">
									<div class="project-item-info-content">
										<h3 class="project-item-title">
											<a href="projects-single.html">Ancraft Avenue House</a>
										</h3>
										<p class="project-cat">Residential</p>
									</div>
								</div>
							</div>
						</div><!-- Isotope item 6 end -->
					</div><!-- Isotop end -->

					<div class="general-btn text-center">
						<a class="btn btn-primary" href="projects.html">View All Projects</a>
					</div>

				</div><!-- Content row end -->
			</div>
			<!--/ Container end -->
		</section><!-- Project area end -->

		<section class="content">
			<div class="container">
				<div class="row">
					<div class="col-md-6">
						<h3 class="column-title">Testimonials</h3>

						<div id="testimonial-slide" class="owl-carousel owl-theme testimonial-slide">
							<div class="item">
								<div class="quote-item">
									<span class="quote-text">
										Thsi section will be deleted.
									</span>

									<div class="quote-item-footer">
										<img class="testimonial-thumb" src="images/clients/testimonial1.png" alt="testimonial">
										<div class="quote-item-info">
											<h3 class="quote-author">Gabriel Denis</h3>
											<span class="quote-subtext">Chairman</span>
										</div>
									</div>
								</div><!-- Quote item end -->
							</div>
							<!--/ Item 1 end -->

							<div class="item">
								<div class="quote-item">
									<span class="quote-text">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci done idunt ut
										labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitoa tion ullamco laboris
										nisi aliquip consequat.
									</span>

									<div class="quote-item-footer">
										<img class="testimonial-thumb" src="images/clients/testimonial2.png" alt="testimonial">
										<div class="quote-item-info">
											<h3 class="quote-author">Weldon Cash</h3>
											<span class="quote-subtext">CFO, First Choice</span>
										</div>
									</div>
								</div><!-- Quote item end -->
							</div>
							<!--/ Item 2 end -->

							<div class="item">
								<div class="quote-item">
									<span class="quote-text">
										Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor inci done idunt ut
										labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitoa tion ullamco laboris
										nisi ut commodo consequat.
									</span>

									<div class="quote-item-footer">
										<img class="testimonial-thumb" src="images/clients/testimonial3.png" alt="testimonial">
										<div class="quote-item-info">
											<h3 class="quote-author">Minter Puchan</h3>
											<span class="quote-subtext">Director, AKT</span>
										</div>
									</div>
								</div><!-- Quote item end -->
							</div>
							<!--/ Item 3 end -->

						</div>
						<!--/ Testimonial carousel end-->
					</div><!-- Col end -->

					<div class="col-md-6">

						<h3 class="column-title">Happy Clients</h3>

						<div class="row all-clients">
							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client1.png" alt="" /></a>
								</figure>
							</div><!-- Client 1 end -->

							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client2.png" alt="" /></a>
								</figure>
							</div><!-- Client 2 end -->

							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client3.png" alt="" /></a>
								</figure>
							</div><!-- Client 3 end -->

							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client4.png" alt="" /></a>
								</figure>
							</div><!-- Client 4 end -->

							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client5.png" alt="" /></a>
								</figure>
							</div><!-- Client 5 end -->

							<div class="col-sm-4">
								<figure class="clients-logo">
									<a href="#"><img class="img-responsive" src="images/clients/client6.png" alt="" /></a>
								</figure>
							</div><!-- Client 6 end -->

						</div><!-- Clients row end -->

					</div><!-- Col end -->

				</div>
				<!--/ Content row end -->
			</div>
			<!--/ Container end -->
		</section><!-- Content end -->

		<section class="subscribe no-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-4 col-sm-12 col-xs-12">
						<div class="subscribe-call-to-acton">
							<h3>Can We Help?</h3>
							<h4>88029999999</h4>
						</div>
					</div><!-- Col end -->

					<div class="col-md-8 col-sm-12 col-xs-12">
						<div class="ts-newsletter">
							<div class="newsletter-introtext">
								<h4>Newsletter Sign-up</h4>
								<p>Latest updates and news</p>
							</div>

							<div class="newsletter-form">
								<form action="#" method="post">
									<div class="form-group">
										<input type="email" name="email" id="newsletter-form-email" class="form-control form-control-lg"
											placeholder="Your Email Here" autocomplete="off">
									</div>
								</form>
							</div>
						</div><!-- Newsletter end -->
					</div><!-- Col end -->

				</div><!-- Content row end -->
			</div>
			<!--/ Container end -->
		</section>
		<!--/ News end -->

		<section id="news" class="news">
			<div class="container">
				<div class="row text-center">
					<h2 class="section-title">Work of Excellence</h2>
					<h3 class="section-sub-title">Recent Projects</h3>
				</div>
				<!--/ Title row end -->

				<div class="row">
					<div class="col-md-4 col-xs-12">
						<div class="latest-post">
							<div class="latest-post-media">
								<a href="news-single.html" class="latest-post-img">
									<img class="img-responsive" src="constra/images/building/constr.jpg" alt="img">
								</a>
							</div>
							<div class="post-body">
								<h4 class="post-title">
									<a href="news-single.html">Revenue earnings of Sona Masjid land port has surpassed the target during the period from February to June 2019, informed Dr Shamil Uddin Ahmed Shimul, MP, Shibganj constituency, at a press conference in Chapainawabganj recently.</a>
								</h4>
								<div class="latest-post-meta">
									<span class="post-item-date">
										<i class="fa fa-clock-o"></i> Sept 23, 2019
									</span>
								</div>
							</div>
						</div><!-- Latest post end -->
					</div><!-- 1st post col end -->

					<div class="col-md-4 col-xs-12">
						<div class="latest-post">
							<div class="latest-post-media">
								<a href="news-single.html" class="latest-post-img">
									<img class="img-responsive" src="constra/images/Sonamasjid_001.jpg" alt="img">
								</a>
							</div>
							<div class="post-body">
								<h4 class="post-title">
									<a href="news-single.html">Sonamasjid Land Port to be int’l standard: Shahriar</a>
								</h4>
								<div class="latest-post-meta">
									<span class="post-item-date">
										<i class="fa fa-clock-o"></i> Aug 18, 2019
									</span>
								</div>
							</div>
						</div><!-- Latest post end -->
					</div><!-- 2nd post col end -->

					<div class="col-md-4 col-xs-12">
						<div class="latest-post">
							<div class="latest-post-media">
								<a href="news-single.html" class="latest-post-img">
									<img class="img-responsive" src="constra/images/security/security.jpg" alt="img">
								</a>
							</div>
							<div class="post-body">
								<h4 class="post-title">
									<a href="news-single.html">Enhancing the Security in PSPLL</a>
								</h4>
								<div class="latest-post-meta">
									<span class="post-item-date">
										<i class="fa fa-clock-o"></i> Aug 13, 2019
									</span>
								</div>
							</div>
						</div><!-- Latest post end -->
					</div><!-- 3rd post col end -->
				</div>
				<!--/ Content row end -->

				<div class="general-btn text-center">
					<a class="btn btn-primary" href="news-left-sidebar.html">See All Posts</a>
				</div>

			</div>
			<!--/ Container end -->
		</section>
		<!--/ News end -->

		@include ('constraView.inc.footer')

			

		<!-- Footer end -->


		<!-- Javascript Files
	================================================== -->

		<!-- initialize jQuery Library -->
		<script type="text/javascript" src="{{asset('constra')}}/js/jquery.js"></script>
		<!-- Bootstrap jQuery -->
		<script type="text/javascript" src="{{asset('constra')}}/js/bootstrap.min.js"></script>
		<!-- Owl Carousel -->
		<script type="text/javascript" src="{{asset('constra')}}/js/owl.carousel.min.js"></script>
		<!-- Color box -->
		<script type="text/javascript" src="{{asset('constra')}}/js/jquery.colorbox.js"></script>
		<!-- Isotope -->
		<script type="text/javascript" src="{{asset('constra')}}/js/isotope.js"></script>
		<script type="text/javascript" src="{{asset('constra')}}/js/ini.isotope.js"></script>


    <!-- Google Map API Key-->
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCcABaamniA6OL5YvYSpB3pFMNrXwXnLwU&libraries=places"></script>
		<!-- Google Map Plugin-->
		<script type="text/javascript" src="{{asset('constra')}}/js/gmap3.js"></script>
 
	 <!-- Template custom -->
	 <script type="text/javascript" src="{{asset('constra')}}/js/custom.js"></script>

	</div><!-- Body inner end -->
</body>

</html>